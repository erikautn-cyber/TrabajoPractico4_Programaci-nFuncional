-- UTN - Facultad Regional Mendoza
-- Paradigmas de Programacion - Paradigma Funcional
-- Alumna: Coronel Erika

-- DEFINICIONES FUNCIONALES

-- ESQUEMA DE PATRONES
-- 1. Potencia por productos, con patrones. Exponente natural.
potencia :: Int -> Int -> Int
potencia _ 0 = 1
potencia b e = if e < 0 then error "Exponente negativo"
               else b * potencia b (e - 1)

-- 2. Valor absoluto, con patrones sobre el resultado de la comparacion.
valAbsoluto :: Int -> Int
valAbsoluto n = absolutoSegun (n < 0) n
  where
    absolutoSegun True x = -x
    absolutoSegun False x = x

-- 3. Suma de los primeros N naturales. Se incluye el caso N = 0.
sumatoria :: Int -> Int
sumatoria 0 = 0
sumatoria n = if n < 0 then error "Se requiere un natural"
              else n + sumatoria (n - 1)

-- 4. Divisor por restas sucesivas y patrones; nunca usa mod.
-- Cero no se admite como divisor. Todo divisor no nulo divide a cero.
divisor :: Int -> Int -> Bool
divisor 0 _ = False
divisor d n = restar (valAbsoluto d) (valAbsoluto n)
  where
    restar _ 0 = True
    restar a b = decidir (b < a) a b
    decidir True _ _ = False
    decidir False a b = restar a (b - a)


-- ESQUEMA DE GUARDAS
-- 5. Se cambia el nombre para conservar ambas versiones en el archivo.
divisorG :: Int -> Int -> Bool
divisorG d n
  | d == 0 = False
  | n < 0 || d < 0 = divisorG (valAbsoluto d) (valAbsoluto n)
  | n == 0 = True
  | n < d = False
  | otherwise = divisorG d (n - d)

-- 6. Algoritmo de Euclides por restos, con guardas.
mcd :: Int -> Int -> Int
mcd a b
  | a < 0 || b < 0 = mcd (valAbsoluto a) (valAbsoluto b)
  | b == 0 = a
  | otherwise = mcd b (a `mod` b)

-- FUNCIONES LAMBDA
-- 7. Mayor de dos valores (Int -> Int -> Int)
-- \x y -> if x > y then x else y

-- 8. Verificar si un valor es par (Int -> Bool)
-- \x -> x `mod` 2 == 0

-- TRATAMIENTO DE LISTAS
-- 9. Subsecuencias: cada elemento puede estar o no en el resultado.
q1 :: [a] -> [[a]]
q1 [] = [[]]
q1 (x:xs) = [x:ys | ys <- sub] ++ sub
  where sub = q1 xs

-- 10. El resultado conserva el tipo numerico de los elementos.
suma :: Num a => [a] -> a
suma [] = 0
suma (x:xs) = x + suma xs

-- 11.
cantidad :: [a] -> Int
cantidad [] = 0
cantidad (_:xs) = 1 + cantidad xs

-- 12. Version con patrones.
ultimo :: [a] -> a
ultimo [] = error "Lista vacia"
ultimo [x] = x
ultimo (_:xs) = ultimo xs

-- 12. Version con guardas.
ultimoG :: [a] -> a
ultimoG xs
  | null xs = error "Lista vacia"
  | null (tail xs) = head xs
  | otherwise = ultimoG (tail xs)

-- Auxiliar: union concatena listas; conserva orden y repeticiones.
union :: [a] -> [a] -> [a]
union [] ys = ys
union (x:xs) ys = x : union xs ys

-- 13.
inversa :: [a] -> [a]
inversa [] = []
inversa (x:xs) = union (inversa xs) [x]

-- 14. Version con patrones. Posicion inexistente: lista sin cambios.
sacar :: Int -> [a] -> [a]
sacar _ [] = []
sacar 1 (_:xs) = xs
sacar n (x:xs) = if n < 1 then x:xs
                 else union [x] (sacar (n - 1) xs)

-- 14. Version con guardas.
sacarG :: Int -> [a] -> [a]
sacarG n xs
  | null xs = []
  | n < 1 = xs
  | n == 1 = tail xs
  | otherwise = union [head xs] (sacarG (n - 1) (tail xs))

-- 15. Elimina todas las apariciones; requiere comparar por igualdad.
eliminar :: Eq a => a -> [a] -> [a]
eliminar _ [] = []
eliminar e (x:xs)
  | e == x = eliminar e xs
  | otherwise = x : eliminar e xs

pertenece :: Eq a => a -> [a] -> Bool
pertenece _ [] = False
pertenece e (x:xs) = e == x || pertenece e xs

-- 16. Interseccion sin repetidos, en el orden de la primera lista.
intersec :: Eq a => [a] -> [a] -> [a]
intersec [] _ = []
intersec (x:xs) ys
  | pertenece x ys = x : intersec (eliminar x xs) ys
  | otherwise = intersec xs ys

-- 17. Rotacion izquierda. Cantidad natural; se reduce por longitud.
rotarIzq :: Int -> [a] -> [a]
rotarIzq _ [] = []
rotarIzq n xs
  | n < 0 = error "Rotacion negativa"
  | otherwise = rotar (n `mod` cantidad xs) xs
  where
    rotar 0 ys = ys
    rotar k (y:ys) = rotar (k - 1) (union ys [y])
    rotar _ [] = []

-- 18. Posiciones validas: 1 a longitud + 1.
insertarEn :: Int -> a -> [a] -> [a]
insertarEn 1 e xs = e:xs
insertarEn _ _ [] = error "Posicion de insercion invalida"
insertarEn n e (x:xs)
  | n < 1 = error "Posicion de insercion invalida"
  | otherwise = x : insertarEn (n - 1) e xs

-- 19. La lista de entrada debe estar ordenada de menor a mayor.
insertOrd :: Ord a => a -> [a] -> [a]
insertOrd e [] = [e]
insertOrd e (x:xs)
  | e <= x = e:x:xs
  | otherwise = x : insertOrd e xs

-- 20. Ordenamiento por insercion.
ordenada :: Ord a => [a] -> [a]
ordenada [] = []
ordenada (x:xs) = insertOrd x (ordenada xs)


-- INSTANCIACION PARCIAL
-- 21. map (potencia 2) [0,1,2,3,4] => [1,2,4,8,16]
-- 22. map (mcd 12) [8,18,24,25] => [4,6,12,1]


-- ESTRUCTURAS DE DATOS
-- 23. Listas de igual longitud; se informa si no cumplen la condicion.
parejas :: [a] -> [a] -> [(a,a)]
parejas [] [] = []
parejas (x:xs) (y:ys) = (x,y) : parejas xs ys
parejas _ _ = error "Las listas deben tener igual longitud"

-- 24. Se corrige el espacio faltante en 'data Mov'.
data Mov = N Int | S Int | E Int | O Int deriving (Eq, Show)
data Paseo a = Pasos Mov (Paseo a) | Descansa a deriving (Eq, Show)

paseo :: Paseo Int
paseo = Pasos (N 20) (Pasos (S 30) (Pasos (E 10) (Pasos (O 40) (Descansa 0))))

-- 25. La descripcion corresponde a map: funcion unaria, polimorfica.
aplica :: (a -> b) -> [a] -> [b]
aplica _ [] = []
aplica f (x:xs) = f x : aplica f xs

-- Alternativa si se desea recibir la funcion binaria que dice el prototipo:
-- hace falta indicar tambien el argumento que se fija.
aplicaBinaria :: (Int -> Int -> Int) -> Int -> [Int] -> [Int]
aplicaBinaria f fijo xs = aplica (f fijo) xs

-- 26. Circuito: (no e1 Y e2) O (e1 Y no e2), equivalente a XOR.
type Entradas = (Bool, Bool)

_and :: Entradas -> Bool
_and (True, True) = True
_and _ = False

_or :: Entradas -> Bool
_or (False, False) = False
_or _ = True

_not :: Bool -> Bool
_not True = False
_not False = True

circuito :: Entradas -> Bool
circuito (e1,e2) = _or (_and (_not e1,e2), _and (e1,_not e2))

tablaCircuito :: [(Entradas,Bool)]
tablaCircuito = [(e,circuito e) | e <- [(False,False),(False,True),(True,False),(True,True)]]


-- ARBOL BINARIO
-- 27. El dibujo tiene valores en las hojas, no en los nodos internos.
data Arbol a = Hoja a | Nodo (Arbol a) (Arbol a) deriving (Eq, Show)

arbol :: Arbol Int
arbol = Nodo (Nodo (Hoja 45) (Hoja 78))
             (Nodo (Hoja 12) (Nodo (Hoja 23) (Hoja 13)))

-- Cuenta todos los nodos, incluidas las hojas.
cantidadNodos :: Arbol a -> Int
cantidadNodos (Hoja _) = 1
cantidadNodos (Nodo izq der) = 1 + cantidadNodos izq + cantidadNodos der

-- Valores de las hojas de izquierda a derecha.
valores :: Arbol a -> [a]
valores (Hoja x) = [x]
valores (Nodo izq der) = union (valores izq) (valores der)

-- Profundidad en aristas: la raiz esta en el nivel 0.
profundidad :: Arbol a -> Int
profundidad (Hoja _) = 0
profundidad (Nodo izq der) = 1 + max (profundidad izq) (profundidad der)

reemplazarHoja :: Eq a => a -> Arbol a -> Arbol a -> Arbol a
reemplazarHoja buscado nuevo (Hoja x)
  | buscado == x = nuevo
  | otherwise = Hoja x
reemplazarHoja buscado nuevo (Nodo izq der) =
  Nodo (reemplazarHoja buscado nuevo izq) (reemplazarHoja buscado nuevo der)

arbolModificado :: Arbol Int
arbolModificado = reemplazarHoja 23 (Nodo (Hoja 30) (Hoja 23)) arbol

-- Verificacion: evaluar 'pruebas' debe devolver True.
-- Estas expresiones son verificaciones ejecutables, no un registro de ejecucion.
pruebas :: Bool
pruebas = and
  [ potencia 2 5 == 32
  , potencia 7 0 == 1
  , valAbsoluto (-8) == 8
  , valAbsoluto 0 == 0
  , sumatoria 5 == 15
  , divisor 3 12 && not (divisor 5 12)
  , divisor (-3) 12 && divisor 3 0 && not (divisor 0 12)
  , and [divisor a b == divisorG a b | a <- [-5..5], b <- [-20..20]]
  , mcd 48 18 == 6 && mcd 0 8 == 8
  , ((\x y -> if x >= y then x else y) (8::Int) 3) == 8
  , (\x -> x `mod` 2 == 0) (6::Int)
  , q1 [1,2] == [[1,2],[1],[2],[]]
  , suma [1,2,3] == (6::Int)
  , suma [1.5,2.25] == (3.75::Float)
  , cantidad [4,5,6] == 3
  , ultimo [1,2,3] == 3 && ultimoG [1,2,3] == 3
  , inversa [1,2,3] == [3,2,1]
  , sacar 2 [10,20,30] == [10,30]
  , and [sacar n [1,2,3] == sacarG n [1,2,3] | n <- [-1..5]]
  , eliminar 2 [2,1,2,3,2] == [1,3]
  , intersec [1,2,2,3] [2,3,4] == [2,3]
  , rotarIzq 5 [1,2,3,4] == [2,3,4,1]
  , insertarEn 3 9 [1,2] == [1,2,9]
  , insertOrd 3 [1,2,4] == [1,2,3,4]
  , ordenada [3,1,2,1] == [1,1,2,3]
  , map (potencia 2) [0,1,2,3,4] == [1,2,4,8,16]
  , map (mcd 12) [8,18,24,25] == [4,6,12,1]
  , parejas [1,2] [3,4] == [(1,3),(2,4)]
  , aplica (+1) [1,2,3] == [2,3,4]
  , aplicaBinaria potencia 2 [1,2,3] == [2,4,8]
  , map snd tablaCircuito == [False,True,True,False]
  , cantidadNodos arbol == 9
  , valores arbol == [45,78,12,23,13]
  , profundidad arbol == 3
  , cantidadNodos arbolModificado == 11
  , valores arbolModificado == [45,78,12,30,23,13]
  , profundidad arbolModificado == 4
  ]
